// index.js
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const userRoutes = require('./routes/userRoutes');
const generalRoutes = require('./routes/generalRoutes');
const billingRoutes = require('./routes/billingRoutes');
const localInformationRoutes = require('./routes/localInformationRoutes');
const entryOptionRoutes = require('./routes/entryOptionRoutes');
const referenceRoutes = require('./routes/referenceRoutes');
const billingDetailRoutes = require('./routes/billingDetailRoutes');



const app = express();

// Connect to MongoDB databases for user
const userDB = mongoose.createConnection('mongodb://localhost:27017/user_db',);

userDB.on('connected', () => {
  console.log('User database connected successfully');
});
//for general information
const generalDB = mongoose.createConnection('mongodb://localhost:27017/general_db', );

generalDB.on('connected', () => {
  console.log('general database connected successfully');
});
//db for accounting
const AccDB = mongoose.createConnection('mongodb://localhost:27017/accounting', );

AccDB.on('connected', () => {
  console.log('Accounting database connected successfully');
});

//db for order
const orderDB = mongoose.createConnection('mongodb://localhost:27017/order', );

orderDB.on('connected', () => {
  console.log('order database connected successfully');
});
//db for Refrence
refrenceDB = mongoose.createConnection('mongodb://localhost:27017/references', );

refrenceDB.on('connected', () => {
  console.log('refrences database connected successfully');
});


  



app.use(express.json());



// Configure body-parser
app.use(bodyParser.urlencoded({ extended: false }));

//ROUTES

app.use('/', express.static(__dirname + '/public')); // Serve static files (HTML, CSS, JS)

// Set up routes for the user
app.use('/user', userRoutes);

// Set up routes for the general
app.use('/general', generalRoutes);

// Set up routes for the accounting database
app.use('/billings', billingRoutes);

// Set up routes for the order db
app.use('/local-information', localInformationRoutes);
app.use('/entry-option', entryOptionRoutes);

//setup route for refrences db
app.use('/references', referenceRoutes);
app.use('/billingdetails', billingDetailRoutes);



const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
