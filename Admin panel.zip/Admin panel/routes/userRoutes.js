const express = require('express');
const router = express.Router();
const UserDetails = require('../models/userDetails');
const userController = require('../controllers/userController')(UserDetails);

router.use('/', userController);

module.exports = router;
