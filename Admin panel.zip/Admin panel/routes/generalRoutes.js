const express = require('express');
const router = express.Router();
const GeneralInformation = require('../models/generalInformation');
const generalController = require('../controllers/generalController')(GeneralInformation);

router.use('/', generalController);

module.exports = router;
