const express = require('express');
const router = express.Router();

module.exports = function(GeneralInformation) {
  // GET all general information
  router.get('/', async (req, res) => {
    try {
      const generalInfo = await GeneralInformation.find();
      res.json(generalInfo);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });

  // GET a specific general information
  router.get('/:id', getGeneralInfo, (req, res) => {
    res.json(res.generalInfo);
  });

  // CREATE a new general information
  router.post('/', async (req, res) => {
    const general = new GeneralInformation(req.body);
    try {
      const newGeneralInfo = await general.save();
      res.status(201).json(newGeneralInfo);
    } catch (err) {
      res.status(400).json({ message: err.message });
    }
  });

  // UPDATE general information
  router.patch('/:id', getGeneralInfo, async (req, res) => {
    if (req.body.businessUnit != null) {
      res.generalInfo.businessUnit = req.body.businessUnit;
    }
    if (req.body.customerType != null) {
      res.generalInfo.customerType = req.body.customerType;
    }
    if (req.body.customerSource != null) {
      res.generalInfo.customerSource = req.body.customerSource;
    }
    try {
      const updatedGeneralInfo = await res.generalInfo.save();
      res.json(updatedGeneralInfo);
    } catch (err) {
      res.status(400).json({ message: err.message });
    }
  });

  // DELETE general information
  router.delete('/:id', getGeneralInfo, async (req, res) => {
    try {
      await res.generalInfo.remove();
      res.json({ message: 'Deleted General Information' });
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  });

  async function getGeneralInfo(req, res, next) {
    try {
      const generalInfo = await GeneralInformation.findById(req.params.id);
      if (generalInfo == null) {
        return res.status(404).json({ message: 'Cannot find general information' });
      }
      res.generalInfo = generalInfo;
      next();
    } catch (err) {
      return res.status(500).json({ message: err.message });
    }
  }

  return router;
};
